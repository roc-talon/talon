// fake main.zig of c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c1
