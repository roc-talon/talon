// fake std 0.17.0
