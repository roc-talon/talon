// fake std 0.15.1
